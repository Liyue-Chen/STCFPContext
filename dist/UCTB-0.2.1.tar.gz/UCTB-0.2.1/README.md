# STCFP Context

## Project 

This repository provides the data and code for reproducing the experiment results of `Exploring Context Modeling Techniques on the Spatiotemporal Crowd Flow Prediction`.

