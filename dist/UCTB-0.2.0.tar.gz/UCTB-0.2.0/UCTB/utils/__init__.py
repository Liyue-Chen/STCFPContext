from .multi_threads import multiple_process
from .encode_onehot import one_hot
from .make_predict_dataset import save_predict_in_dataset